package virtual.classroom;
public class VirtualClassRoom {
    public static void main(String[] args) {
        // TODO code application logic here
        Login l1 = new Login();
        l1.setVisible(true);
    }
    
}
