/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package virtual.classroom;
import java.sql.*;
import javax.swing.*;

/**
 *
 * @author Asraful
 */
public class DB {
          private Connection con;
          private Statement st;
          private ResultSet rs;
          public DB(){
                    try {
                               Class.forName("com.mysql.jdbc.Driver");
            
                               con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Virtual_Classroom", "root", "");
            
                               st = con.createStatement();
                    }
                    catch(Exception e){
                               System.out.println("Error:" + e);
                               e.printStackTrace();
                    }
          }
}
